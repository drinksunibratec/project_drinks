<?php
/**
 * Configura��o de Variaveis
 */
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASSWORD", "");
define("DB_DATABASE", "drinks");

define("DB_DNS", "mysql:dbname=drinks;host=localhost");

define("ESTABELECIMENTO", "estabelecimento");
define("PRODUTO", "produto");
define("CLIENTE", "cliente");

?>