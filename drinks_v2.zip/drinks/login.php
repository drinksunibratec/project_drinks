<?php
require_once ('biblioteca/util/Mensagens.php');
require_once ('biblioteca/functions/DB_Functions.php');

session_start();


$mensagens = new Mensagens();

$mensagens->clear_message('codEstabelecimento');
$mensagens->clear_message('administrador');


if (isset($_POST['email']) && empty($_POST['email']) == false) {
    $email = addslashes($_POST['email']);
    $senha = addslashes($_POST['senha']);
    
    $result = login(ESTABELECIMENTO, $email, $senha);
    
    if ($result) {
        $_SESSION['codEstabelecimento'] = $result['codEstabelecimento'];
        $_SESSION['administrador'] = $result['administrador'];
        
        header("Location: administrador/estabelecimento/cadastro-estabelecimentos.php");
    }else{
        echo '<div class="alert alert-danger" role="alert">';
        echo '<strong>Aviso!</strong> Verifique se digitou o login corretamente.';
        echo '</div>';
    }
    
}
?>
<!--<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
	rel="stylesheet">
<link rel="stylesheet" type="text/css"
	href="biblioteca/materialize/css/materialize.min.css">
<link href="css/login.css" rel="stylesheet">


</head>
   

<body>
	<div class="section"></div>
	<main>
	<center>
		<div class="section"></div>

		<h5 class="indigo-text" font-color="#000">Por favor, entre na sua conta</h5>
		<div class="section"></div>

                <div class="container" >
			<div class="z-depth-1 grey lighten-5 row" 
				style="display: inline-block; padding: 32px 48px 0px 48px; border: 1px solid #000;">

				<form class="col s12" method="POST" >
					<div class='row'>
						<div class='col s12'></div>
					</div>

					<div class='row'>
						<div class='input-field col s12'>
							<input class='validate' type='email' name='email' id='email' required/> <label
								for='email' >Coloque seu email</label>
						</div>
					</div>

					<div class='row'>
						<div class='input-field col s12'>
							<input class='validate' type='password' name='senha'
								id='password' required/> <label for='password'>Coloque sua senha</label>
						</div>
						 <label style='float: right;'> <a class='pink-text' href='#!'><b>Esqueceu a senha?</b></a></label> 

						
					</div>

					<br />
					<div class='row'>
						<button type='submit' name='btn_login'
							class='col s12 btn btn-large waves-effect indigo'>Entrar</button>
					</div>
				</form>
			</div>
		</div>
		 <a href="#!">Create account</a> 
	</center>

	<div class="section"></div>
	<div class="section"></div>
	</main>

	<script type="text/javascript"
		src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.1/jquery.min.js"></script>
	<script type="text/javascript"
		src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.5/js/materialize.min.js"></script>
</body>

</html>
-->

<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml"
      xmlns:og="http://ogp.me/ns#"
      xmlns:fb="https://www.facebook.com/2008/fbml">
  <head>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="msvalidate.01" content="36A28D9109C077BA3E623651FC1656F4" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta property="fb:admins" content="19908503" />
    <meta property="fb:app_id" content="112989545392380" /> 
    <meta property="og:title" content="HTML Snippets for Twitter Boostrap framework : Bootsnipp.com" />
    <meta property="og:type" content="website" />
    <meta property="twitter:account_id" content="786331568" />
      <meta itemprop="name" content="Bootsnipp">
    <meta itemprop="description" content="Free HTML snippets for Bootstrap HTML CSS JS">
    <meta property="og:url" content="https://bootsnipp.com" />
      <meta property="og:image" content="https://bootsnipp.com/img/logo.jpg" />
    <meta property="og:site_name" content="Bootsnipp.com" />
      <meta property="og:description" content="A design element gallery for web designers and web developers. Find snippets using HTML, CSS, Javascript, jQuery, and Bootstrap." />
    <meta name="description" content="A design element gallery for web designers and web developers. Find snippets using HTML, CSS, Javascript, jQuery, and Bootstrap">
      <!--<title>Login to free code playground for Bootstrap | Bootsnipp.com</title>-->
    <link rel="shortcut icon" href="//d2d3qesrx8xj6s.cloudfront.net/favicon.ico" type="image/x-icon">
    <link rel="icon" href="//d2d3qesrx8xj6s.cloudfront.net/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon-precomposed" href="//d2d3qesrx8xj6s.cloudfront.net/apple-touch-icon-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="//d2d3qesrx8xj6s.cloudfront.net/apple-touch-icon-72x72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="//d2d3qesrx8xj6s.cloudfront.net/apple-touch-icon-114x114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="//d2d3qesrx8xj6s.cloudfront.net/apple-touch-icon-144x144-precomposed.png">
    <link rel="alternate" type="application/rss+xml" title="Latest snippets from Bootsnipp.com" href="https://bootsnipp.com/feed.rss" />

    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.min.css">
<!--    <link rel="stylesheet" href="//d2d3qesrx8xj6s.cloudfront.net/dist/bootsnipp.min.css?ver=872ccd9c6dce18ce6ea4d5106540f089">-->
    <link rel="stylesheet" href="/dist/bootsnipp.min.css">
    <style type="text/css">
	
	body{
		background: #000\9;
                padding: 10%;
	}
	.form-signin input[type="text"] {
	  margin-bottom: -1px;
	  border-bottom-left-radius: 0;
	  border-bottom-right-radius: 0;
	}
	.form-signin input[type="password"] {
	  margin-bottom: 10px;
	  border-top-left-radius: 0;
	  border-top-right-radius: 0;
	}
	.form-signin .form-control {
	  position: relative;
	  font-size: 16px;
	  height: auto;
	  padding: 10px;
	  -webkit-box-sizing: border-box;
	     -moz-box-sizing: border-box;
	          box-sizing: border-box;
	}

</style>
</script>

    
</head>
  <body>

    <nav class="navbar navbar-fixed-top navbar-bootsnipp animate" role="navigation" style="z-index: 9999999">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <div class="animbrand">
          <a class="navbar-brand animate" style="color: #db4437"><h3>Drink's</h3></a>
      </div>
    </div>
    
  </div>

</nav>
      <div class="container">
	<div class="row" style="margin-top:30px;">
		<div class="col-md-4 col-md-offset-4">
			<!--<form method="POST" action="https://bootsnipp.com/login" accept-charset="UTF-8" role="form" id="loginform" class="form-signin"><input name="_token" type="hidden" value="Uzgr9hw4m4g8Rqe9oSQfNwA5nyijU4MYq74LbSQy">-->
                    <form class="col s12" method="POST" >
				<fieldset>
			  		<h1 class="sign-up-title" style="color:#db4437; text-align: center">Bem Vindo a Tela de Login</h1>
                                        <br>
                                        
			  		<h3 class="sign-up-title" style="color:#db4437; text-align: center">Por favor, entre na sua conta</h3>
					<br>	
						
			  		<hr class="colorgraph">
                                            <input class="form-control email-title" placeholder="E-mail" name="email" type="email" id="email" style="background: #000">
                                                <input class="form-control" placeholder="Password" name="senha" type="password" id="password" style="background: #000">
                                                
                                                
				    <!--<a class="pull-right" href="https://bootsnipp.com/password">Forgot password?</a>-->
					<div class="checkbox" style="width:140px;">
				    	<!--<label><input name="remember" type="checkbox" value="Remember Me"> Remember Me</label>-->
				    </div>
<!--                                    <div class='row'>
						<button type='submit' name='btn_login'
							class='col s12 btn btn-large waves-effect indigo'>Entrar</button>
					</div>-->
                                    <button class="btn btn-lg btn-success btn-block" style="background: darkgray" 
                                            type="submit" name="btn_login" value="Logar">Entrar</button>
				    <!--<p class="text-center" style="margin-top:10px;">OR</p>-->
				    <!--<a class="btn btn-default btn-block" href="https://bootsnipp.com/login/github"><i class="icon-github"></i> Login with Github</a>-->
				  	<br>
				  	<!--<p class="text-center"><a href="https://bootsnipp.com/register">Register for an account?</a></p>-->
			  	</fieldset>
		  	</form>
		</div>
  	</div>

    <script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
    <script src="/dist/scripts.min.js"></script>
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
      </body>
</html>