<?php session_start()?>
<!DOCTYPE html>
<html>
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  .affix {
      top: 0;
      width: 100%;
      -webkit-transition: all .5s ease-in-out;
      transition: all .5s ease-in-out;
      background-color: #F44336;
      border-color: #F44336;

  }
  .affix a {
      color: #fff !important;
      padding: 15px !important;
      -webkit-transition: all .5s ease-in-out;
      transition: all .5s ease-in-out;
  }
  .affix-top a {
      padding: 25px !important;
  }
  .affix + .container-fluid {
      padding-top: 95px;
  }
  </style>
</head>
<body>

<div class="container-fluid" style="background-color:#F44336;color:#fff;height:200px;">
  <h1>Drink's</h1>
  <h3>Serviço Delivery</h3>
  <p>Você está logado.</p>
  <p>Bem Vindo Sr. Cliente.</p>
</div>
    
<style>
 .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }
    
  .carousel-inner img {
      width: 40%; /* Set width to 100% */
      /*height: 400px;*/
      margin: auto;
      min-height:200px;
  }

  /* Hide the carousel text when the screen is less than 600 pixels wide */
  @media (max-width: 600px) {
    .carousel-caption {
      display: none;
      padding-top: 50px;
    }
  }
  /********************************************************************/
  
  .affix {
      top: 0;
      width: 100%;
      -webkit-transition: all .5s ease-in-out;
      transition: all .5s ease-in-out;
      background-color: #F44336;
      border-color: #F44336;

  }
  .affix a {
      color: #fff !important;
      padding: 15px !important;
      -webkit-transition: all .5s ease-in-out;
      transition: all .5s ease-in-out;
  }
  .affix-top a {
      padding: 25px !important;
  }
  .affix + .container-fluid {
      padding-top: 95px;
  }
  </style>
  
<!--<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">-->
<nav class="navbar navbar-inverse" data-spy="affix" data-offset-top="197">
  <ul class="nav navbar-nav">
    <div class="navbar-header">
        <img src="../../biblioteca/img/copo.png" width="40" height="50"/>
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
        <a class="navbar-brand">Drink's</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
<!--        <li><a href="#">Estabelecimento</a></li>
        <li><a href="#">Cliente</a></li>
        <li><a href="#">Produto</a></li>
        <li><a href="#">Sair</a></li>-->
<li><a href="../../administrador/estabelecimento/cadastro-estabelecimentos.php">Estabelecimentos</a></li>
					<?php if(!empty($_SESSION['administrador']) && $_SESSION['administrador'] == 1){ ?>
						<li><a href="../../administrador/cliente/cadastro-cliente.php">Clientes</a></li>
					<?php }else{?>
						<li><a href="../../administrador/produto/cadastrar-produto.php">Produtos</a></li>
					<?php }?>
					
					
                                                <li><a href="../../index.php">Sair</a></li>
      </ul>
<!--      <ul class="nav navbar-nav navbar-right">
          <li><a href="./login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
      </ul>-->
    </div>
  </div>
</nav>

