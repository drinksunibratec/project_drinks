<?php
require_once './biblioteca/menu/menu_abertura.php';
//require_once './biblioteca/css/custom.css';
require_once './biblioteca/include/header.php';

//session_start();


